import UIKit

func flattenArray(nestedArray: [Any]) -> [Int] {
  var finalArray = [Int]()
  
  for element in nestedArray {
    if element is Int {
      finalArray.append(element as! Int)
    } else {
      let recursionResult = flattenArray(nestedArray: element as! [Any])
      
      for num in recursionResult {
        finalArray.append(num)
      }
    }
  }
  return finalArray
}

let result = flattenArray(nestedArray: [1, [2], [3, [4], [5, [6, 7], -1]]])
print(result)

